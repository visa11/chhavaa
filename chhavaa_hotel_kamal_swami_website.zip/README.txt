HOTEL KAMAL SWAMI — CHHAVAA.COM

Files:
- index.html : responsive one-page website
- assets/logo1.jpg : supplied Hotel Kamal Swami logo

To publish on chhavaa.com:
1. Upload index.html and the assets folder to your hosting public_html/www root.
2. Point the chhavaa.com domain DNS to the hosting account if not already connected.
3. Replace the "View Full Menu" button (#) with the hotel's actual Google Menu/PDF link.
4. Replace sample Google reviews with actual customer reviews.
